package RedesZone;

public class Empezar {

    public static void main(String args[]) {
        MenuPrincipal mp = new MenuPrincipal();
    }
}
